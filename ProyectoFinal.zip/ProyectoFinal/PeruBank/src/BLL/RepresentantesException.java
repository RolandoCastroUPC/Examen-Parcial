package BLL;

public class RepresentantesException extends Exception {
	public RepresentantesException(String mensaje){
        super(mensaje);
    }
}
