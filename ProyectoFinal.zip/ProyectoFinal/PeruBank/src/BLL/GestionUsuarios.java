package BLL;

import java.util.ArrayList;
import java.util.List;

import ENT.Cliente;
import ENT.TipoUsuario;
import ENT.Usuarios;


public class GestionUsuarios {
	
	 List<Usuarios> listaUsuarios = new ArrayList<Usuarios>();
	 public GestionUsuarios()
	 {
		
		 listaUsuarios.add(new Usuarios("administrador","administrador",TipoUsuario.ADMINISTRADOR));	
		 listaUsuarios.add(new Usuarios("supervisor","supervisor",TipoUsuario.SUPERVISOR));
		 listaUsuarios.add(new Usuarios("abogado","abogado",TipoUsuario.ABOGADO));
		 listaUsuarios.add(new Usuarios("empleado","empleado",TipoUsuario.EMPLEADO));

		
	 }
	 Usuarios Usuario = null;
	 public boolean ValidaAutenticacionUsuario(String cuenta, String contrasena) {
		 boolean existe = false;
	        for(Usuarios usuario : listaUsuarios)
	            if (usuario.getCuenta().equals(cuenta) && usuario.getContrasena().equals(contrasena) )
	            {
	            	Usuario = usuario;
	            	existe = true;
	            }
	                
	        return existe;
		}
	 
	 public Usuarios getUsuario()
	 {
		 return Usuario;
	 }

}
