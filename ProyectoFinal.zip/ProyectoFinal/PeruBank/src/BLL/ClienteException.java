package BLL;

public class ClienteException extends Exception {

	
    public ClienteException(String mensaje){
        super(mensaje);
    }
}
