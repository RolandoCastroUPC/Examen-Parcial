package BLL;
import java.util.ArrayList;
import java.util.List;

import ENT.GrupoBastanteo;
import ENT.Representantes;
import BLL.GestionUsuarios;

public class AdmRepresentantes {
	
	//1ero. defino mi lista de un tipo dado
	List<Representantes> representantes;
	
	//2do. En el constructor inicializo
	public AdmRepresentantes(){
		representantes = new ArrayList<Representantes>();
	}
	
	public void registrarRepresentante(	String tipoDocumento,
			int numeroDocumento,
			String nombres,
			String apellidos,
			String cargo,
			GrupoBastanteo grupoBastanteo) 
			throws RepresentantesException 
			{
		
		
		

		
		//validar datos	
	    validarDatos(tipoDocumento,
			 numeroDocumento,
			 nombres,
			 apellidos,
			 cargo,
			grupoBastanteo);	
	    
	    
	    //validar que no haya duplicados
	    validarDuplicado(tipoDocumento, numeroDocumento);
	    
		
		//Creamos un cliente
	    Representantes nuevoRepresentante = new Representantes(tipoDocumento,
				 numeroDocumento,
				 nombres,
				 apellidos,
				 cargo,
				 grupoBastanteo);
	    
		//a�aden a la lista
		representantes.add(nuevoRepresentante);
		
	}

	
	public void validarDuplicado(String tipo,
			int numdoc) throws RepresentantesException
			 {		
	    
        if(RepresentanteExiste(tipo,numdoc)) 
        	throw new RepresentantesException("Representante Duplicado");
	}
	
	private boolean RepresentanteExiste(String tipo,
			int numdoc
			) {
		boolean existe = false;
	    
	    //   and &&   , || or
        for(Representantes representante : representantes)
            if (representante.getTipoDocumento().equals(tipo) &&
            		representante.getNumeroDocumento() == numdoc)
                existe = true;
		return existe;
	}
	
	public void validarDatos(	String tipoDocumento,
			int numeroDocumento,
			String nombres,
			String apellidos,
			String cargo,
			GrupoBastanteo grupoBastanteo ) throws RepresentantesException {
		String mensaje = "";
	    if (tipoDocumento.equals(""))
	        mensaje += "Tipo de documento no puede ser vacio";
	    if (numeroDocumento == 0 )
	        mensaje += "\nN�mero De Documento no puede ser vacio";
	    if (nombres.equals(""))
	        mensaje += "\nNombre   no puede ser vacio";
	    if (apellidos.equals(""))
	        mensaje += "\nApellidos no puede ser vacio";
	    if (cargo.equals(""))
	        mensaje += "\nCargo no puede ser vacio";
	    if (grupoBastanteo == null)
	        mensaje += "\nEl grupo de bastanteo no puede ser posible";
	    
	    if (! mensaje.equals(""))
	        throw  new RepresentantesException(mensaje);
	}
	
	public Representantes buscarRepresentante(String apellidos) {
        for(Representantes representante : representantes)
            if (representante.getApellidos().equals(apellidos))
                return representante;
        return null;
	}

}
