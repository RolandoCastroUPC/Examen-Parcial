package ENT;

public class GrupoBastanteo {

	String Nombre = "";
	int ID = 0;
	public GrupoBastanteo(String Nombre, int id)
	{
		this.ID = id;
		this.Nombre = Nombre;
		
	}
}
