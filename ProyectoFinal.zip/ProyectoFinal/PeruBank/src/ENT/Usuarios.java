package ENT;

public class Usuarios {

	String Cuenta = "";
	String Contrasena = "";
	TipoUsuario TipodeUsuario;
	public Usuarios()
	{
	
	}
	public Usuarios(	String cuenta,
			String contrasena,
			TipoUsuario tipodeUsuario)
	{
		this.Cuenta = cuenta;
		this.Contrasena = contrasena;
		this.TipodeUsuario = tipodeUsuario;
	}
	
	public String getCuenta() {return Cuenta;}
	public String getContrasena() {return Contrasena;}
	public TipoUsuario getTipodeUsuario() {return TipodeUsuario;}
}
