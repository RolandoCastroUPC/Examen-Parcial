package ENT;



/*
 Cuando:
Inscribo un representante debo indicar su
 tipo y n�mero de documento, 
 sus nombres y apellidos, 
 cargo en la empresa y un grupo de bastanteo (A, B, C, etc.).
Espero:
- Confirmaci�n de la inscripci�n Ok.
- Mensaje de error si no se ingresan los datos requeridos.
- Mensaje de error si ya es representante de la empresa (seg�n tipo y n�mero de documento).
3. Agregar poderes.- Como supervisor
 */
public class Representantes {
	
	String TipoDocumento = "";
	int NumeroDocumento = 0;
	String Nombres = "";
	String Apellidos = "";
	String Cargo = "";
	GrupoBastanteo GrupoBastanteo = null;
	
	public Representantes(	String tipoDocumento,
			int numeroDocumento,
			String nombres,
			String apellidos,
			String cargo,
			GrupoBastanteo grupoBastanteo)
	{
		this.TipoDocumento = tipoDocumento;
		this.NumeroDocumento = numeroDocumento;
		this.Nombres = nombres;
		this.Apellidos = apellidos;
		this.Cargo = cargo;
		this.GrupoBastanteo = grupoBastanteo;
	}
	public GrupoBastanteo getGrupoBastanteo()
	{
	  return GrupoBastanteo;
	}
	public String getACargo()
	{
	  return Cargo;
	}
	public String getApellidos()
	{
	  return Apellidos;
	}
	public String getNombres()
	{
	  return Nombres;
	}
	public int getNumeroDocumento()
	{
	  return NumeroDocumento;
	}

	public String getTipoDocumento()
	{
	  return TipoDocumento;
	}

}
