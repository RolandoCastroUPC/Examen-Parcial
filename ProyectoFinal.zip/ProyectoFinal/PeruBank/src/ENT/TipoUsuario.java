package ENT;

public enum TipoUsuario {
	
	   ADMINISTRADOR, SUPERVISOR, ABOGADO, EMPLEADO, CLIENTE

}
