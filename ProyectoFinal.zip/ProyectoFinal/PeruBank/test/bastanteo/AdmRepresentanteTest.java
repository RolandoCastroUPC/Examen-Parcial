package bastanteo;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import junit.extensions.RepeatedTest;
import junit.framework.Assert;

import org.junit.Test;

import BLL.AdmRepresentantes;
import BLL.GestionUsuarios;
import BLL.RepresentantesException;
import ENT.GrupoBastanteo;
import ENT.Representantes;
import ENT.TipoUsuario;

public class AdmRepresentanteTest {
	
	@Test
	public void siIngresoDatosDeberiaRegistrarRepresentante() throws RepresentantesException{
		
		//preparamos el ejemplo
		String tipoDocumento = "TIP 01";
		int numeroDocumento = 6969;
		String nombres = "CHRISTIAN";
		String apellidos = "RUIZ";
		String cargo = "JEFE DE AREA";
		GrupoBastanteo grupoBastanteo =  new GrupoBastanteo("Grupo 01",1); //null ;
		TipoUsuario tipoUsuario ;
		tipoUsuario = TipoUsuario.ABOGADO;
        AdmRepresentantes  adm = new AdmRepresentantes();	
		
        
        
        //ejecutar
        
		GestionUsuarios gestionUsuarios = new 	GestionUsuarios();
		//DEBERIA VALIDAR USUARIO
		gestionUsuarios.ValidaAutenticacionUsuario("abogado", "abogado");
		
		//SIN PRIVILEGIOS
		//gestionUsuarios.ValidaAutenticacionUsuario("abogado", "abogado");
		
		assertNotNull(gestionUsuarios.getUsuario());

		assertEquals(gestionUsuarios.getUsuario().getTipodeUsuario(), tipoUsuario);
		
        adm.registrarRepresentante(tipoDocumento, numeroDocumento, nombres, apellidos, cargo, grupoBastanteo);
 
        
        Representantes cliente = adm.buscarRepresentante(apellidos);
        // Verificar
        assertNotNull(cliente);
	}

	/*private boolean assertEquals(TipoUsuario tipodeUsuario, TipoUsuario tipoUsuario2) {
		// TODO Auto-generated method stub
		if(tipodeUsuario == tipoUsuario2)return true;
		else return false;
	}*/
	

}
